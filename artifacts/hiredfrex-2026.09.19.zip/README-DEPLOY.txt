HiredFrex — Netlify drag-and-drop zip
Build: 2026.09.19 (same premium site as 2026.08.09)

WHAT CHANGED (only this)
- Admin panel restored to the original dashboard:
  Overview · Employers · Jobs · Applications · Users · Blog · Messages · API Keys
- After you log in with ADMIN_TOKEN, Blog tab: pick an author (or type a custom name)
  and optionally upload an author photo. Featured article image works as before.
- Jobs, applications, users, employers, messages — unchanged.
- Frontend, jobs rail, auth, email OTP, content — unchanged.

HOW TO DEPLOY
1. Netlify → hiredfrex.com → Deploys
2. Drag this zip onto the deploy drop zone (the zip itself, not an unzipped folder)
3. Wait ~60 seconds, then hard-refresh (Ctrl+Shift+R)
4. Footer should read: build 2026.09.19
5. Open https://hiredfrex.com/admin.html
   Paste ADMIN_TOKEN → Connect → Blog tab → author + photo while posting

Do not change Netlify build settings. Publish directory stays "."
Keep existing env vars: DATABASE_URL, JWT_SECRET, ADMIN_TOKEN,
SENDGRID_API_KEY (or later RESEND_API_KEY if you migrate email),
EMAIL_FROM, OWNER_EMAIL, APP_URL, ANTHROPIC_API_KEY.

Author photo columns are added automatically on first blog save.
Optional (Neon SQL Editor), same as schema.sql tail:
  alter table blog_posts add column if not exists author_photo_data text;
  alter table blog_posts add column if not exists author_photo_mime text;

wipe-cvs.sql — run in Neon only if you still want CVs erased. It does not delete jobs or blogs.
