HiredFrex — publication + job portal
Build: 2026.09.19-desk

WHAT THIS IS
- Main site = daily career publication (articles, desks, research from OUR jobs only)
- /jobs = existing job portal (search, apply, CV, employer dashboard)
- /admin.html = ORIGINAL admin (jobs, blogs, users, messages, API keys)
  Blog tab now also has author role, bio, reviewer, review date, sources, methodology.

DEPLOY
Netlify → Deploys → drag this zip (the zip file, not a folder).
Publish directory stays "."
Keep env vars: DATABASE_URL, JWT_SECRET, ADMIN_TOKEN, SENDGRID_API_KEY,
EMAIL_FROM, OWNER_EMAIL, APP_URL, ANTHROPIC_API_KEY.

Footer stamp: build 2026.09.19-desk
JOBS in the top category bar goes to /jobs.

Do not run a Netlify build command. No Git required.
