HiredFrex — insights homepage (sample layout) + original job portal + original admin
Build: 2026.09.19-sample

PUBLIC
- Homepage matches the blog-focused sample: navy header, featured article,
  topic pills, article feed, labeled ad slots, Seeking/Hiring + Open roles rail.
- Articles load from /api/blog (what you publish in admin).
- Open roles load from /api/jobs (approved listings only).
- Jobs / CV Builder / apply / employer dashboard are unchanged.

ADMIN
- Unchanged dashboard: Overview, Employers, Jobs, Applications, Users, Blog,
  Messages, API Keys.
- Blog still has author, photo, role, bio, reviewer, sources, methodology.

DEPLOY
Netlify → Deploys → drag this zip (the file, not a folder).
Publish directory stays "."
Keep existing env vars.

Footer: build 2026.09.19-sample
Admin: https://hiredfrex.com/admin.html
